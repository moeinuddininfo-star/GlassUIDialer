package com.mmu.dialer

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun GlassBackground(dark: Boolean, content: @Composable BoxScope.() -> Unit) {
    val bg = if (dark) listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E))
             else listOf(Color(0xFFA1C4FD), Color(0xFFC2E9FB), Color(0xFFFBC2EB))
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(bg))) {
        Box(Modifier.size(260.dp).offset((-60).dp, 80.dp).blur(80.dp).background(Color(0xFF7F5AF0), RoundedCornerShape(50)))
        Box(Modifier.size(220.dp).align(androidx.compose.ui.Alignment.BottomEnd).offset(40.dp, (-120).dp).blur(80.dp).background(Color(0xFF2CB67D), RoundedCornerShape(50)))
        content()
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, radius: Int = 24, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(radius.dp)
    Box(modifier.clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(0.22f), Color.White.copy(0.07f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.6f), Color.White.copy(0.05f))), shape),
        content = content)
}
