package com.mmu.dialer

import android.app.*
import android.content.*
import android.media.*
import android.os.IBinder
import android.telephony.TelephonyManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

fun recDir(c: Context) = File(c.getExternalFilesDir(null), "MMU_Recordings").apply { mkdirs() }
fun recEnabled(c: Context) = c.getSharedPreferences("p", 0).getBoolean("rec", false)
fun setRecEnabled(c: Context, v: Boolean) = c.getSharedPreferences("p", 0).edit().putBoolean("rec", v).apply()

class CallStateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!recEnabled(c)) return
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_OFFHOOK -> c.startForegroundService(Intent(c, RecorderService::class.java))
            TelephonyManager.EXTRA_STATE_IDLE -> c.stopService(Intent(c, RecorderService::class.java))
        }
    }
}

class RecorderService : Service() {
    private var mr: MediaRecorder? = null
    private var am: AudioManager? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "rec"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Recording", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("MMU Dialer: recording call")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        am = getSystemService(AudioManager::class.java).also { it.mode = AudioManager.MODE_IN_CALL; it.isSpeakerphoneOn = true }
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a"
        try {
            mr = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(File(recDir(this@RecorderService), name).absolutePath)
                prepare(); start()
            }
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        try { mr?.stop() } catch (_: Exception) {}
        mr?.release(); mr = null
        am?.isSpeakerphoneOn = false; am?.mode = AudioManager.MODE_NORMAL
    }
}
