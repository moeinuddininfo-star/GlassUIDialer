package com.mmu.dialer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { val dark = isSystemInDarkTheme(); App(dark) }
    }
}

fun callNumber(c: android.content.Context, n: String) {
    if (n.isBlank()) return
    c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
}

@Composable
fun App(dark: Boolean) {
    val ctx = LocalContext.current
    val fg = if (dark) Color.White else Color(0xFF1B1B2F)
    var tab by remember { mutableStateOf(0) }
    var granted by remember { mutableStateOf(0) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted++ }
    LaunchedEffect(Unit) {
        perms.launch(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
    }
    CompositionLocalProvider(LocalContentColor provides fg) {
        GlassBackground(dark) {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
                Text("MMU Dialer", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> Dialpad()
                        1 -> ListTab(remember(granted) { loadCalls(ctx) }, true)
                        2 -> ListTab(remember(granted) { loadContacts(ctx) }, false)
                        else -> Settings()
                    }
                }
                GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp), 32) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                        listOf(Icons.Default.Dialpad, Icons.Default.History, Icons.Default.Contacts, Icons.Default.Settings).forEachIndexed { i, ic ->
                            IconButton({ tab = i }) { Icon(ic, null, tint = if (tab == i) Color(0xFF7F5AF0) else fg.copy(0.7f)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Dialpad() {
    val ctx = LocalContext.current
    var num by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(num.ifEmpty { " " }, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(16.dp))
        listOf("123", "456", "789", "*0#").forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                row.forEach { ch -> GlassCard(Modifier.size(76.dp).clickable { num += ch }, 38) {
                    Text(ch.toString(), fontSize = 28.sp, modifier = Modifier.align(Alignment.Center)) } }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Spacer(Modifier.size(56.dp))
            GlassCard(Modifier.size(76.dp).clickable { callNumber(ctx, num) }, 38) {
                Icon(Icons.Default.Call, null, tint = Color(0xFF2CB67D), modifier = Modifier.align(Alignment.Center).size(34.dp)) }
            IconButton({ num = num.dropLast(1) }, Modifier.size(56.dp)) { Icon(Icons.Default.Backspace, null) }
        }
    }
}

@Composable
fun ListTab(items: List<Entry>, log: Boolean) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val shown = items.filter { q.isBlank() || it.name.contains(q, true) || it.number.contains(q) }
    Column {
        if (!log) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown) { e ->
                GlassCard(Modifier.fillMaxWidth().clickable { callNumber(ctx, e.number) }, 18) {
                    Column(Modifier.padding(14.dp)) {
                        Text(e.name.ifBlank { e.number }, fontWeight = FontWeight.SemiBold)
                        if (e.name != e.number) Text(e.number, fontSize = 13.sp, color = LocalContentColor.current.copy(0.7f))
                    }
                }
            }
        }
    }
}

@Composable
fun Settings() {
    val ctx = LocalContext.current
    var rec by remember { mutableStateOf(recEnabled(ctx)) }
    val files = remember { recDir(ctx).listFiles()?.sortedDescending() ?: emptyList() }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Call recording", fontWeight = FontWeight.SemiBold)
                    Text("Mic + speaker mode. Onno pokkho-ke janiye record koro; onek desh e consent lage.", fontSize = 12.sp)
                }
                Switch(rec, { rec = it; setRecEnabled(ctx, it) })
            }
        }
        Text("Recordings (${files.size})", fontWeight = FontWeight.SemiBold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(files) { f -> GlassCard(Modifier.fillMaxWidth(), 16) { Text(f.name, Modifier.padding(12.dp), fontSize = 13.sp) } }
        }
    }
}
