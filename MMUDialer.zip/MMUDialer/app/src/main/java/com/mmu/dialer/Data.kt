package com.mmu.dialer

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract

data class Entry(val name: String, val number: String, val type: Int = 0)

fun loadCalls(c: Context): List<Entry> = try {
    val out = mutableListOf<Entry>()
    c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE),
        null, null, CallLog.Calls.DATE + " DESC")?.use {
        while (it.moveToNext() && out.size < 100) out += Entry(it.getString(0) ?: it.getString(1) ?: "", it.getString(1) ?: "", it.getInt(2))
    }; out
} catch (e: SecurityException) { emptyList() }

fun loadContacts(c: Context): List<Entry> = try {
    val out = mutableListOf<Entry>()
    c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
        null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use {
        while (it.moveToNext()) out += Entry(it.getString(0) ?: "", it.getString(1) ?: "")
    }; out
} catch (e: SecurityException) { emptyList() }
